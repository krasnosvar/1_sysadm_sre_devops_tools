print("Сколько тебе лет?", end=' ')
age = input()
print("Каков твой рост?", end=' ')
height = input()
print("Сколько ты весишь?", end=' ')
weight = input()

print(f"Итак, тебе {age} лет, в тебе {height} см роста и {weight} кг веса.")