from nose.tools import *
import NAME

def setup():
    print("УСТАНОВКА!")

def teardown():
    print("ЗАВЕРШЕНИЕ!")

def test_basic():
    print("ВЫПОЛНЕНИЕ!")