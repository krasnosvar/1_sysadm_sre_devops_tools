d_artagnan = "\tМеня зовут д'Артаньян."
athos = "Эта строка\nразделена на две."
porthos = "Я \\ - \\ мушкетер!"

aramis = """
Подсказки:
\t* Граф из Гаскони
\t* Связан с Миледи
\t* Барон\n\t* Генерал Ордена
"""

print(d_artagnan)
print(athos)
print(porthos)
print(aramis)