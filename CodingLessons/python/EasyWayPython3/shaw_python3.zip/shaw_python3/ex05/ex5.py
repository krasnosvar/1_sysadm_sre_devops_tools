my_name = 'Зед Шоу'
my_age = 35 # это правда!
my_height = 188 # см
my_weight = 80 # кг
my_eyes = 'Голубые'
my_teeth = 'Белые'
my_hair = 'Каштановые'

print(f"Давайте поговорим о человеке по имени {my_name}.")
print(f"Его рост составляет {my_height} см.")
print(f"Он весит {my_weight} кг.")
print("На самом деле это не так и много.")
print(f"У него {my_eyes} глаза и {my_hair} волосы.")
print(f"Его зубы обычно {my_teeth}, хотя он и любит пить кофе.")

# эта строка кода довольно сложная, не ошибитесь!
total = my_age + my_height + my_weight
print(f"Если я сложу {my_age}, {my_height} и {my_weight}, то получу {total}.")
